//
//  ViewController.swift
//  CoreDataDemo
//
//  Created by agilemac-9 on 4/25/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet var txtId: UITextField!
    @IBOutlet var txtName: UITextField!
    @IBOutlet var txtMobile: UITextField!
    
    @IBOutlet var txtFind: UITextField!
    @IBOutlet var txtDelete: UITextField!
    
    @IBOutlet var btnSave: UIButton!
    
    var result = [Employee]()
    var employeeDetails = Employee()

    var objectId = NSManagedObjectID()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func ActionSave(_ sender: UIButton)
    {
        if btnSave.titleLabel?.text == "Save" {
            
            var dict = [String:Any]()
            dict["emo_id"] = txtId.text
            dict["emp_name"] = txtName.text
            dict["emp_mobile"] = txtMobile.text
            
            CoreDataServiceManager.storeEmployee(employeeDetail: dict)
        }else{
            
            var dict = [String:Any]()
            dict["emo_id"] = txtId.text
            dict["emp_name"] = txtName.text
            dict["emp_mobile"] = txtMobile.text
            
            CoreDataServiceManager.updateEmployee(id: objectId, dict: dict)

            txtId.text = ""
            txtName.text = ""
            txtMobile.text = ""
            btnSave.setTitle("Save", for: .normal)
        }
    }
    
    @IBAction func ActionShow(_ sender: UIButton)
    {
        result = CoreDataServiceManager.getEmployees()
        print(result.count)
    }
    
    @IBAction func ActionFind(_ sender: UIButton)
    {
        employeeDetails = CoreDataServiceManager.getEmployeeBy(id: txtFind.text!)[0]
        
        txtId.text = employeeDetails.emo_id
        txtName.text = employeeDetails.emp_name
        txtMobile.text = employeeDetails.emp_mobile
        objectId = employeeDetails.objectID
        btnSave.setTitle("Update", for: .normal)
    }
    
    @IBAction func ActionDelete(_ sender: UIButton)
    {
        employeeDetails = CoreDataServiceManager.getEmployeeBy(id: txtDelete.text!)[0]
        CoreDataServiceManager.deleteEmployee(id: employeeDetails.objectID)
        print("Delete Success")
    }
}

